# 始動操作中の高電圧バッテリー電流（2026年10月21日 13:27）
reset
load 'common.gp'
set output 'hv_current.eps'
set xlabel '時刻 [s]'
set ylabel '電流 [A]'
set xrange [0:15]
set yrange [-1:6.5]
set key top right
plot 'data/hv_current.dat' u 1:2 w lp pt 7 ps 0.8 lc rgb 'black' lw 1.5 title 'バッテリ電流', \
     5.5 w l dt 2 lc rgb 'black' lw 1 title 'P311Cの判定値（5.5 A）'
unset output
