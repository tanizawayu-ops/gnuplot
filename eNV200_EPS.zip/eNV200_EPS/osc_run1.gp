# 1回目の補機バッテリー電圧（外部給電なし・ブレーキ5秒・音あり）
reset
load 'common.gp'
set output 'osc_run1.eps'
set title '1回目　外部給電なし・ブレーキ5秒・音あり'
set xlabel '時刻 [s]'
set ylabel '電圧 [V]'
set xrange [-25.00:25.00]
set yrange [11.8:13.7]
set key bottom left
# 網掛け：ポンプモータの作動区間
set object 1 rect from 0.47,graph 0 to 2.27,graph 1 behind fc rgb 'gray80' fs solid 0.5 noborder
plot 'data/osc_run1.dat' u 1:2 w l lc rgb 'gray50' lw 1 title '瞬時値', \
     'data/osc_run1_avg50.dat' u 1:2 w l lc rgb 'black' lw 2 title '50 ms平均', \
     12.5 w l dt 2 lc rgb 'black' lw 1 title '12.5 V（トリガ設定値）'
unset output
unset object
