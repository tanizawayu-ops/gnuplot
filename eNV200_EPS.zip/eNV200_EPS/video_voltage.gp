# 診断機の電圧表示（動画から0.5 s間隔で読み取り、130点）
reset
load 'common.gp'
set output 'video_voltage.eps'
set xlabel '時刻 [s]'
set ylabel '電圧 [V]'
set xrange [0:75]
set yrange [11.5:13.2]
set key bottom right
plot 'data/video_voltage.dat' u 1:2 w lp pt 7 ps 0.7 lc rgb 'black' lw 1 title '診断機の電圧表示'
unset output
