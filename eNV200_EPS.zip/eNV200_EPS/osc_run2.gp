# 2回目の補機バッテリー電圧（外部給電なし・ブレーキ5秒・音なし）
reset
load 'common.gp'
set output 'osc_run2.eps'
set title '2回目　外部給電なし・ブレーキ5秒・音なし'
set xlabel '時刻 [s]'
set ylabel '電圧 [V]'
set xrange [-4.00:16.00]
set yrange [11.8:13.7]
set key bottom left
plot 'data/osc_run2.dat' u 1:2 w l lc rgb 'gray50' lw 1 title '瞬時値', \
     'data/osc_run2_avg50.dat' u 1:2 w l lc rgb 'black' lw 2 title '50 ms平均', \
     12.5 w l dt 2 lc rgb 'black' lw 1 title '12.5 V（トリガ設定値）'
unset output
unset object
