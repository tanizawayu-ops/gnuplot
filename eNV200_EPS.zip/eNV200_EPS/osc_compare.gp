# 2回目（音なし）と3回目（音あり）の比較（50 ms平均）
reset
load 'common.gp'
set output 'osc_compare.eps'
set xlabel '時刻 [s]'
set ylabel '電圧 [V]'
set xrange [-4:16]
set yrange [11.8:13.0]
set key bottom right
plot 'data/osc_run2_avg50.dat' u 1:2 w l lc rgb 'black' lw 2 dt 2 title '2回目（音なし）', \
     'data/osc_run3_avg50.dat' u 1:2 w l lc rgb 'black' lw 2 title '3回目（音あり）'
unset output
