# 7回の補機電圧のまとめ（縦線：瞬時最小〜最大、点：50 ms平均の最小）
reset
load 'common.gp'
set output 'aux_voltage.eps'
set xlabel '回'
set ylabel '電圧 [V]'
set xrange [0.5:7.5]
set yrange [10.5:14.0]
set xtics 1
set key top left
set arrow from 5.5,graph 0 to 5.5,graph 1 nohead lc rgb 'gray50'
set label '外部給電なし' at 3,13.85 center
set label '外部給電あり' at 6.5,13.85 center
plot 'data/aux_summary.dat' u 1:2:3:4 w yerrorbars pt 7 ps 1.5 lc rgb 'black' lw 2 title '50 ms平均の最小（縦線は瞬時最小〜最大）', \
     11.0 w l dt 2 lc rgb 'black' lw 1 title 'DTC確認条件（11 V以上）'
unset output
