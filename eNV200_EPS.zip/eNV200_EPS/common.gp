# 共通設定（各スクリプトの先頭で読み込む）
# 日本語が文字化けする場合は font の名前を環境に合わせて変更してください
#   Mac: "Hiragino Sans,14"  Windows: "Meiryo,14"  Linux: "Noto Sans CJK JP,14"
set encoding utf8
set terminal epscairo color noenhanced size 12in,7in font "Noto Sans CJK JP,14"
set grid
set border lw 1
set tics nomirror
