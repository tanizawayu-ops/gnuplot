reset
load 'common.gp'
set output 'hydrogen_usage.eps'
unset key
set multiplot layout 2,1 title '水素消費量の推移' margins 0.16,0.96,0.12,0.88 spacing 0.02,0.09
unset xlabel
set format x ''
set ylabel 'mH2_g [g]'
set yrange [0:0.035]
plot DATA skip 1 using 1:6 with lines linestyle 1
set xlabel 't（単位記載なし）'
set format x '%g'
set ylabel '累積水素量 [g]'
set yrange [0:17]
plot DATA skip 1 using 1:7 with lines linestyle 2
unset multiplot
unset output
