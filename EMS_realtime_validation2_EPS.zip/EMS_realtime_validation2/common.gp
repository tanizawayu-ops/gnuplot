# 共通設定。CSV の t 列には単位の記載がありません。
set encoding utf8
set terminal epscairo color noenhanced size 10in,6in font "Noto Sans CJK JP,16"
set datafile separator comma
set datafile missing ""
DATA = 'data/EMSリアルタイム性検証2.csv'
set border linewidth 1.2
set grid xtics ytics linewidth 0.6 linecolor rgb '#cccccc'
set tics nomirror
set xrange [0:589]
set xlabel 't（単位記載なし）'
set key opaque box linewidth 0.5 spacing 1.1
set style line 1 linecolor rgb '#0072B2' linewidth 2.2
set style line 2 linecolor rgb '#D55E00' linewidth 2.2 dashtype 2
set style line 3 linecolor rgb '#009E73' linewidth 2.2 dashtype 4
set style line 4 linecolor rgb '#333333' linewidth 1.4 dashtype 3
