# 下段は CSV 末尾の無名列。jitter_ms の隣接差と一致します。
# t の単位は不明のため時間微分や周期誤差とは呼びません。
reset
load 'common.gp'
set output 'realtime_jitter.eps'
unset key
set multiplot layout 2,1 title 'ジッタ値と隣接サンプル差' margins 0.16,0.96,0.12,0.88 spacing 0.02,0.09
unset xlabel
set format x ''
set ylabel 'jitter_ms [ms]'
set yrange [0:80]
plot DATA skip 1 using 1:11 with lines linestyle 1
set xlabel 't（単位記載なし）'
set format x '%g'
set ylabel '隣接差 [ms]'
set yrange [-0.03:0.31]
plot DATA skip 1 using 1:12 with lines linestyle 2, \
     0 with lines linestyle 4
unset multiplot
unset output
