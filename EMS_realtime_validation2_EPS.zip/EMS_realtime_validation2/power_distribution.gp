# Pd_eff_W は全サンプルで P_dem_W と一致するため同じ線で表示します。
reset
load 'common.gp'
set output 'power_distribution.eps'
set title 'EMS の電力配分'
set ylabel '電力 [kW]'
set yrange [-1:9]
set key top left
plot DATA skip 1 using 1:($2/1000.0) with lines linestyle 1 title '要求電力（P_dem_W = Pd_eff_W）', \
     DATA skip 1 using 1:($3/1000.0) with lines linestyle 2 title '燃料電池電力（Pfc_W）', \
     DATA skip 1 using 1:($4/1000.0) with lines linestyle 3 title 'バッテリー電力（Pbat_W）', \
     0 with lines linestyle 4 notitle
unset output
