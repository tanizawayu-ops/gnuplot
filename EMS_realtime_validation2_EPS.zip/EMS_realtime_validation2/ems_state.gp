# lam および status の意味・正常値は元 CSV に未記載です。
reset
load 'common.gp'
set output 'ems_state.eps'
unset key
set multiplot layout 2,1 title 'EMS の状態変数' margins 0.16,0.96,0.12,0.88 spacing 0.02,0.09
unset xlabel
set format x ''
set ylabel 'lam（CSV 原値）'
set yrange [2.13:2.25]
plot DATA skip 1 using 1:8 with lines linestyle 1
set xlabel 't（単位記載なし）'
set format x '%g'
set ylabel 'status（CSV 原値）'
set yrange [-0.5:0.5]
set ytics 0,1,0
plot DATA skip 1 using 1:10 with lines linestyle 2
unset multiplot
unset output
