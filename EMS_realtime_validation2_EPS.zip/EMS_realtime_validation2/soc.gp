reset
load 'common.gp'
set output 'soc.eps'
set title 'バッテリー SOC の推移'
set ylabel 'SOC [%]'
set yrange [59:60.1]
set ytics 0.2
unset key
plot DATA skip 1 using 1:($5*100.0) with lines linestyle 1
unset output
